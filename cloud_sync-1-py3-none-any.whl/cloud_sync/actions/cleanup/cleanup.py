from __future__ import annotations

from cloud_sync.models import Account


def cleanup_inactive_missing_accounts(
    *, exo_accounts: list[Account], scim_accounts: list[Account]
):
    """
    Exclude disabled accounts on EXO that are never created on Zivver
    """
    scim_accounts_emails = {account.email_address for account in scim_accounts}

    accounts: list[Account] = [
        account
        for account in exo_accounts
        if account.is_active or account.email_address in scim_accounts_emails
    ]

    exo_valid_email_addresses = [account.email_address for account in accounts]

    return [
        account.model_copy(
            update={
                "delegations": frozenset(
                    [
                        delegation
                        for delegation in account.delegations
                        if delegation in exo_valid_email_addresses
                    ]
                )
            }
        )
        for account in accounts
    ]
