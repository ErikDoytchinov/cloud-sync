from __future__ import annotations

from cloud_sync.log.log_color import LogColor
from cloud_sync.models.account import Account
from cloud_sync.models.actions.create_action import CreateAction
from cloud_sync.models.actions.update_action import Diff, UpdateAction


def show(actions: list[UpdateAction | CreateAction]) -> str:
    s = "\n"
    for action in actions:
        if isinstance(action, CreateAction):
            s += LogColor.GREEN
        elif isinstance(action, UpdateAction):
            s += LogColor.CYAN
        else:
            s += LogColor.YELLOW

        s += _show_action(action) + "\n"

    s += LogColor.RESET
    return s


def _show_action(action: UpdateAction | CreateAction) -> str:
    if isinstance(action, CreateAction):
        return "CREATE\n" + _show_account(action.account)
    if isinstance(action, UpdateAction):
        return (
            "UPDATE\n"
            + action.account.email_address
            + "\n"
            + LogColor.CYAN
            + _show_diff(action.diff, old_account=action.account)
            + LogColor.RESET
        )


def _show_diff(diff: Diff, old_account: Account) -> str:
    s = ""
    if diff.full_name is not None:
        s += f"\tfull_name:\t{old_account.full_name} -> {diff.full_name} \n"

    if diff.is_active is not None:
        s += f"\tis_active:\t{old_account.is_active} -> {diff.is_active} \n"

    if diff.aliases is not None:
        s += "\taliases:"

        new = diff.aliases
        if len(new) > 0:
            s += "\n"
            for email in new:
                s += f"\t{email}\n"
        else:
            s += f"\t{LogColor.RED}(erases all aliases){LogColor.CYAN}\n"

    if diff.delegations is not None:
        s += "\tdelegations:"

        new = diff.delegations
        if len(new) > 0:
            s += "\n"
            for email in new:
                s += f"\t{email}\n"
        else:
            s += f"\t{LogColor.RED}(erases all delegations){LogColor.CYAN}\n"

    return s


def _show_account(account: Account) -> str:
    s = ""
    s += f"{account.email_address}\n"
    s += LogColor.GREEN
    s += f"\tkind:\t{account.kind}\n"
    s += f"\tfull_name:\t{account.full_name}\n"
    s += f"\tis_active:\t{account.is_active}\n"
    s += "\taliases:"
    if len(account.aliases) == 0:
        s += f"\t\t{LogColor.LIGHTBLACK_EX}(no aliases){LogColor.GREEN}\n"
    else:
        s += "\n"
        for alias in account.aliases:
            s += f"\t\t{alias}\n"
    s += "\tdelegations:"
    if len(account.delegations) == 0:
        s += f"\t\t{LogColor.LIGHTBLACK_EX}(no delegations){LogColor.GREEN}\n"
    else:
        s += "\n"
        for delegation in account.delegations:
            s += f"\t\t{delegation}\n"
    s += LogColor.RESET
    return s.strip()
