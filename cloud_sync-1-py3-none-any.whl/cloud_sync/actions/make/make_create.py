from __future__ import annotations

from cloud_sync.models.account import Account
from cloud_sync.models.actions.create_action import CreateAction
from cloud_sync.models.actions.update_action import Diff, UpdateAction
from cloud_sync.models.exo.exo_context import ExoContext


def make_create_actions(
    *,
    exo_accounts: list[Account],
    scim_accounts: list[Account],
    exo_context: ExoContext,
) -> list[CreateAction | UpdateAction]:
    exo_accounts_emails = {account.email_address for account in exo_accounts}

    scim_accounts_emails = {account.email_address for account in scim_accounts}
    new_emails = exo_accounts_emails - scim_accounts_emails

    # We need to create all the accounts, and only after that, we need to update all
    # of the ones we just created to add their aliases and delegations again.
    # Otherwise the creation will silently fail to add the delegations, and the
    # accounts will still be out of sync.

    return [
        CreateAction(
            account=account,
            sso_key=exo_context.sso_keys.get(account.email_address, None),
        )
        for account in exo_accounts
        if account.email_address in new_emails
    ] + [
        # We need to update the acconts we just created, because backend doesn't read the fields as it should
        # and we need to make sure they are set correctly by updating them.
        UpdateAction(
            account=account,
            diff=Diff(
                full_name=account.full_name,
                # if we create a user where is_active = False, backend will not set it to false.
                # so on the update we need to set it again to make sure its set to false
                is_active=account.is_active,
                aliases=account.aliases,
                delegations=account.delegations,
            ),
        )
        for account in exo_accounts
        if account.email_address in new_emails
    ]
