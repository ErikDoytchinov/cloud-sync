from __future__ import annotations

import logging

from cloud_sync.api.get_distribution_group_member import get_distribution_group_member
from cloud_sync.models.email_address import EmailAddress
from cloud_sync.models.exo.distribution_group_member_response import (
    MemberRecipientTypeDetailsEnum,
)
from cloud_sync.models.exo.mailbox_permissions import (
    ExoMailboxPermissions,
    MailboxPermission,
)
from cloud_sync.models.exo.mailbox_with_permissions import ExoMailboxWithPermissions

Delegations = "dict[EmailAddress, frozenset[EmailAddress]]"

logger = logging.getLogger(__name__)


async def get_delegations(*, accounts: list[ExoMailboxWithPermissions]) -> Delegations:
    account_lookups = {
        account.mailbox.PrimarySmtpAddress: account for account in accounts
    }

    return {
        account.mailbox.PrimarySmtpAddress: frozenset(
            await _get_delegation(
                account=account,
                account_lookups=account_lookups,
            )
        )
        for account in accounts
    }


async def _get_delegation(
    account: ExoMailboxWithPermissions,
    account_lookups: dict[EmailAddress, ExoMailboxWithPermissions],
) -> set[EmailAddress]:
    if account.mailbox.PrimarySmtpAddress not in account_lookups:
        # TODO this should never happen. error log?
        return set()

    permissions = filter_permissions(account.permissions)

    user_permissions: set[str] = {
        permission.User.lower()
        for permission in permissions
        if permission.User.lower() in account_lookups
    }

    group_permissions: set[str] = {
        user
        for permission in permissions
        if permission.User.lower() not in account_lookups
        for user in await _get_users_of(permission.User)
    }

    return user_permissions.union(group_permissions)


async def _get_users_of(group_identity: str) -> set[str]:
    result = await get_distribution_group_member(group_identity)
    return {
        item.PrimarySmtpAddress.lower()
        for item in result.value
        # TODO for now we do not address nested groups and only include user mailboxes as delegates
        if item.RecipientTypeDetails == MemberRecipientTypeDetailsEnum.USER_MAILBOX
    }


def filter_permissions(
    exo_permissions: ExoMailboxPermissions,
) -> list[MailboxPermission]:
    return list(
        exo_permission
        for exo_permission in exo_permissions.value
        if "NT AUTHORITY" not in exo_permission.User
        and any(
            "FullAccess" in permission.AccessRights and permission.IsInherited is False
            for permission in exo_permission.PermissionList
        )
    )
