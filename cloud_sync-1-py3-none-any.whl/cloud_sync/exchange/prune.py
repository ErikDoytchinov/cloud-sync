from __future__ import annotations

import logging

from cloud_sync.models.account import Account
from cloud_sync.models.email_address import EmailAddress

logger = logging.getLogger(__name__)


def prune(accounts: list[Account], claimed_domains: frozenset[str]) -> list[Account]:
    accounts = _prune_unknown_delegations(accounts)
    accounts = _prune_domain_ownership(
        accounts=accounts, claimed_domains=claimed_domains
    )

    return accounts


def _prune_unknown_delegations(accounts: list[Account]) -> list[Account]:
    """
    Prune delegations that are not in the list of accounts, this will compare the delegations of each account
    and compare it to the list of accounts we retrieved from EXO, if it is not in the list of accounts it will be pruned.
    SCIM will throw away any delegations set which are not already created in the system, so we remove them here
    to prevent confusion.
    """
    emails = {account.email_address for account in accounts}

    cleaned = []

    for account in accounts:
        cleaned_delegations = {
            delegation for delegation in account.delegations if delegation in emails
        }

        pruned = set(account.delegations) - cleaned_delegations
        if len(pruned) > 0:
            logger.warning(
                f"Pruned {len(pruned)} delegations for {account.email_address}: {pruned}"
            )

        cleaned.append(
            account.model_copy(
                update={
                    "delegations": frozenset(cleaned_delegations),
                }
            )
        )

    return cleaned


def _prune_domain_ownership(
    accounts: list[Account], claimed_domains: frozenset[str]
) -> list[Account]:
    """
    Prune accounts that are not owned by the organization, this will compare the domain of the email address
    and compare it to the claimed domains, if it is not in the claimed domains it will be pruned.
    """
    all_emails = {account.email_address for account in accounts}

    owned_emails = {
        email for email in all_emails if _is_domain_owned(email, claimed_domains)
    }
    for email in all_emails - owned_emails:
        logger.warning(f"Pruned {email} as it is not owned by the organization")

    return [
        account.model_copy(
            update={
                "delegations": frozenset(
                    [
                        delegation
                        for delegation in account.delegations
                        if _is_domain_owned(delegation, claimed_domains)
                    ]
                ),
                "aliases": frozenset(
                    [
                        alias
                        for alias in account.aliases
                        if _is_domain_owned(alias, claimed_domains)
                    ]
                ),
            }
        )
        for account in accounts
        if _is_domain_owned(account.email_address, claimed_domains)
    ]


def prune_target_accounts(
    exo_accounts: list[Account],
    scim_accounts: list[Account],
    target_filter: frozenset[str],
) -> tuple[list[Account], list[Account]]:
    """
    Prune accounts where the email address contains any part of a target filter.
    This will look at each target filter provided, and will remove the account if the target filter is a substring of the email address.

    E.g.
    target_filter = {'test', 'onmicrosoft'}
    accounts = ['jack@zivver.com', 'erik@test.com', 'anke@zivver.onmicrosoft.com']

    after pruning using target filters...
    accounts = ['jack@zivver.com']
    """
    all_emails = {account.email_address for account in exo_accounts} | {
        account.email_address for account in scim_accounts
    }

    emails_to_prune = {
        email for email in all_emails if _is_targeted(email, target_filter)
    }

    for email in emails_to_prune:
        logger.warning(
            f"Pruned {email} as it is inside the target filter and will not be changed"
        )

    return (
        [
            account
            for account in exo_accounts
            if not _is_targeted(account.email_address, target_filter)
        ],
        [
            account
            for account in scim_accounts
            if not _is_targeted(account.email_address, target_filter)
        ],
    )


def _is_targeted(email: EmailAddress, target_filter: frozenset[str]) -> bool:
    return any(target.lower().strip() in email.lower() for target in target_filter)


def _is_domain_owned(email: EmailAddress, claimed_domains: frozenset[str]) -> bool:
    return any(
        email.lower().strip().split("@")[1] == domain.lower().strip()
        for domain in claimed_domains
    )
