from __future__ import annotations

import logging
from enum import Enum
from uuid import UUID

from pydantic import BaseModel, field_validator

from cloud_sync.models.email_address import EmailAddress

logger = logging.getLogger(__name__)


class DistributionGroupMemberResponse(BaseModel):
    value: list[DistributionGroupMember]


"""
    {
      "PrimarySmtpAddress": "ORGsharedmailbox@zivvertest.onmicrosoft.com",
      "DisplayName": "[ORG] Shared Mailbox Test",
      "RecipientTypeDetails": "MailUniversalDistributionGroup",  
      "Guid": "2a1faf15-c06d-42d9-b442-7755d3d2f5cf"
    },
"""

"""
    {
      "PrimarySmtpAddress": "testplugin5@zivvertest.onmicrosoft.com",
      "DisplayName": "testplugin 5",
      "RecipientTypeDetails": "MailUniversalSecurityGroup",
      "Guid": "5d17bcee-35ed-4445-80d4-9d152af49f83"
    },
"""


class MemberRecipientTypeDetailsEnum(str, Enum):
    UNIVERSAL_DISTRIBUTION_GROUP = "MailUniversalDistributionGroup"
    UNIVERSAL_SECURITY_GROUP = "MailUniversalSecurityGroup"
    USER_MAILBOX = "UserMailbox"


class DistributionGroupMember(BaseModel):
    PrimarySmtpAddress: EmailAddress
    DisplayName: str
    RecipientTypeDetails: MemberRecipientTypeDetailsEnum
    Guid: UUID

    @field_validator("PrimarySmtpAddress", mode="after")
    @classmethod
    def validate_primary_smtp_address(cls, value: str):
        if "@" not in value:
            raise ValueError("PrimarySmtpAddress must contain @")

        # lowercase all email addresses
        value = value.lower().strip()

        return value
