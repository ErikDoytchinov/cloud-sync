from __future__ import annotations

import asyncio
import logging

import httpx
from pydantic import ValidationError
from tenacity import (
    AsyncRetrying,
    RetryError,
    stop_after_attempt,
    wait_random_exponential,
)

import cloud_sync.api.make_httpx_client as mkclient
from cloud_sync.get_access_token import get_tenant_id
from cloud_sync.models.exo.distribution_group_member_response import (
    DistributionGroupMember,
    DistributionGroupMemberResponse,
)
from cloud_sync.settings import get_settings

logger = logging.getLogger(__name__)


async def get_distribution_group_member(
    identity: str,
) -> DistributionGroupMemberResponse:
    tenant_id = get_tenant_id(get_settings().access_token.get_secret_value())

    logger.info("Getting distribution group members from Exchange Online...")

    url = httpx.URL(
        f"https://outlook.office365.com/adminapi/beta/{tenant_id}/InvokeCommand"
    )
    try:
        async for attempt in AsyncRetrying(
            sleep=log_sleep,
            wait=wait_random_exponential(multiplier=1, max=60),
            stop=stop_after_attempt(7),
        ):
            with attempt:
                # {"CmdletInput":{"Parameters":{"ResultSize":"Unlimited","Debug":true},"CmdletName":"Get-DistributionGroup"}}
                async with mkclient.make_httpx_client() as client:
                    request = client.build_request(
                        method="POST",
                        url=url,
                        headers={
                            "Authorization": f"Bearer {get_settings().access_token.get_secret_value()}",
                            "host": "outlook.office365.com",
                            # "X-ResponseFormat": "clixml",
                            "Accept": "application/json",
                            "Accept-Charset": "UTF-8",
                            "Prefer": "odata.maxpagesize=1000",
                            # "connection-id": "057eb733-a857-4324-8164-050c4c03421a",  # TODO can this be dropped?
                            # "client-request-id": "6888a1ed-a86f-43d8-9a0c-293e20f90a3c",  # TODO can this be dropped?
                            "Accept-Language": "en-US",
                            # "X-CmdletName": "Get-DistributionGroup",  # TODO this reappears in request payload.
                            # "X-SerializationLevel": "Partial",
                            # "X-ClientModuleVersion": "3.4.0",
                            # "X-ClientApplication": "ExoManagementModule",
                            # "X-AnchorMailbox": "UPN:sam.prevost@zivvertest.onmicrosoft.com",  # TODO does it fail without this?
                        },
                        json={
                            "CmdletInput": {
                                "CmdletName": "Get-DistributionGroupMember",
                                "Parameters": {"Identity": identity},
                            }
                        },
                    )
                    # logger.info(Curlify(request).to_curl())
                    response = await client.send(request)
    except RetryError as e:
        raise IOError("Failed to get mailbox permission", e)
    else:
        if "value" not in response.json():
            logger.info(
                "Could not find Distribution group members in the Get-DistributionGroupMember response, instead found: "
                + response.text
            )
            return DistributionGroupMemberResponse(value=[])

        members = response.json()["value"]

        distribution_group_members: list[DistributionGroupMember] = []

        for member in members:
            try:
                distribution_group_members.append(DistributionGroupMember(**member))
            except ValidationError as e:
                logger.error("Failed to parse DistributionGroupMember: " + str(e))

        # if len(distribution_group_members) == 0:
        #     logger.error(
        #         "No valid DistributionGroupMember could be parsed from response. Aborting."
        #     )
        #     exit(1)

        logger.info("Done getting groups from Exchange Online!")

        return DistributionGroupMemberResponse(value=distribution_group_members)
    # return DistributionGroupMemberResponse(value=[])


async def log_sleep(seconds: float):
    logger.info(
        f"Backing off for {seconds:.2f} seconds because Microsoft is rate limiting us 😭"
    )
    await asyncio.sleep(seconds)
