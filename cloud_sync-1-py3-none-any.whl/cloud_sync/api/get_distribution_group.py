from __future__ import annotations

import logging

import httpx
from pydantic import ValidationError

import cloud_sync.api.make_httpx_client as mkclient
from cloud_sync.get_access_token import get_tenant_id
from cloud_sync.models.exo.distribution_group_response import (
    DistributionGroup,
    DistributionGroupResponse,
)
from cloud_sync.settings import get_settings

logger = logging.getLogger(__name__)


async def get_distribution_group() -> DistributionGroupResponse:
    tenant_id = get_tenant_id(get_settings().access_token.get_secret_value())

    logger.info("Getting distribution groups from Exchange Online...")

    url = httpx.URL(
        f"https://outlook.office365.com/adminapi/beta/{tenant_id}/InvokeCommand"
    )

    # {"CmdletInput":{"Parameters":{"ResultSize":"Unlimited","Debug":true},"CmdletName":"Get-DistributionGroup"}}
    async with mkclient.make_httpx_client() as client:
        request = client.build_request(
            method="POST",
            url=url,
            headers={
                "Authorization": f"Bearer {get_settings().access_token.get_secret_value()}",
                "host": "outlook.office365.com",
                # "X-ResponseFormat": "clixml",
                "Accept": "application/json",
                "Accept-Charset": "UTF-8",
                "Prefer": "odata.maxpagesize=1000",
                # "connection-id": "057eb733-a857-4324-8164-050c4c03421a",  # TODO can this be dropped?
                # "client-request-id": "6888a1ed-a86f-43d8-9a0c-293e20f90a3c",  # TODO can this be dropped?
                "Accept-Language": "en-US",
                # "X-CmdletName": "Get-DistributionGroup",  # TODO this reappears in request payload.
                # "X-SerializationLevel": "Partial",
                # "X-ClientModuleVersion": "3.4.0",
                # "X-ClientApplication": "ExoManagementModule",
                # "X-AnchorMailbox": "UPN:sam.prevost@zivvertest.onmicrosoft.com",  # TODO does it fail without this?
            },
            json={
                "CmdletInput": {
                    "Parameters": {"ResultSize": "Unlimited", "Debug": "true"},
                    "CmdletName": "Get-DistributionGroup",
                }
            },
        )
        # logger.info(Curlify(request).to_curl())
        response = await client.send(request)
    if "value" not in response.json():
        logger.error(
            "Could not find Distribution groups in the Get-DistributionGroup response instead found: "
            + response.text
        )
        return DistributionGroupResponse(value=[])

    groups = response.json()["value"]

    distribution_groups: list[DistributionGroup] = []

    for group in groups:
        try:
            distribution_groups.append(DistributionGroup(**group))
        except ValidationError as e:
            logger.error("Failed to parse DistributionGroup: " + str(e))

    if len(distribution_groups) == 0:
        logger.error(
            "No valid DistributionGroup could be parsed from response. Aborting."
        )
        exit(1)

    logger.info("Done getting groups from EXO!")

    return DistributionGroupResponse(value=distribution_groups)
