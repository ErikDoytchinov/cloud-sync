from __future__ import annotations

import logging

import httpx
from pydantic import ValidationError

import cloud_sync.api.make_httpx_client as mkclient
from cloud_sync.get_access_token import get_tenant_id
from cloud_sync.models.exo.mailbox_response import ExoMailbox, ExoMailboxResponse
from cloud_sync.settings import get_settings

logger = logging.getLogger(__name__)


async def get_exo_mailbox() -> ExoMailboxResponse:
    tenant_id = get_tenant_id(get_settings().access_token.get_secret_value())

    logger.info("Getting mailboxes from Microsoft Exchange Online...")

    url = httpx.URL(f"https://outlook.office365.com/adminapi/beta/{tenant_id}/Mailbox")

    async with mkclient.make_httpx_client() as client:
        request = client.build_request(
            method="GET",
            url=url,
            params={
                "$select": ",".join(
                    [
                        "PrimarySmtpAddress",
                        "DisplayName",
                        "EmailAddresses",
                        "RecipientTypeDetails",
                        "Guid",
                        "AccountDisabled",
                        "ExternalDirectoryObjectId",
                    ]
                )
            },
            headers={
                "Accept": "application/json;odata.metadata=minimal",
                "Authorization": f"Bearer {get_settings().access_token.get_secret_value()}",
                "ps-version": "7.2.9",
                "is-cloud-shell": "True",
                "os-version": "Unix 14.4.1",
                "exomodule-version": "3.4.0",
                "Prefer": "odata.maxpagesize=1000;",
                "OData-Version": "4.0",
                "OData-MaxVersion": "4.0",
            },
        )
        # logger.info(Curlify(request).to_curl())
        response = await client.send(request)
    if "value" not in response.json():
        logger.error(
            "Could not find EXO mailboxes in the GetEXOMailbox response instead found: "
            + response.text
        )
        exit(1)
    mailboxes = response.json()["value"]
    exo_mailboxes: list[ExoMailbox] = []

    for mailbox in mailboxes:
        try:
            exo_mailboxes.append(ExoMailbox(**mailbox))
        except ValidationError as e:
            error_details = "   |   ".join(
                [
                    f"\t{error['loc'][0]} - {error['msg']} - input is '{error['input']}'"
                    for error in e.errors()
                ]
            )
            logger.error(
                f"Failed to parse ExoMailbox, {e.error_count()} errors: {error_details}"
            )

    if len(exo_mailboxes) == 0:
        logger.error("No valid ExoMailbox could be parsed from response. Aborting.")
        exit(1)

    logger.info("Done getting mailboxes from Microsoft Exchange Online!")

    return ExoMailboxResponse(value=exo_mailboxes)
