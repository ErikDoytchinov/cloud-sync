import logging

from cloud_sync.settings import get_settings
from cloud_sync.version import __version__

MESSAGE = r"""
‎ ‎ ‎ _____‎ _‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ _‎ ‎ _____‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ 
‎ ‎ /‎ ____|‎ |‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ |‎ |/‎ ____|‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ 
‎ |‎ |‎ ‎ ‎ ‎ |‎ |‎ ___‎ ‎ _‎ ‎ ‎ _‎ ‎ __|‎ |‎ (___‎ ‎ _‎ ‎ ‎ _‎ _‎ __‎ ‎ ‎ ___‎ 
‎ |‎ |‎ ‎ ‎ ‎ |‎ |/‎ _‎ \|‎ |‎ |‎ |/‎ _`‎ |\___‎ \|‎ |‎ |‎ |‎ '_‎ \‎ /‎ __|
‎ |‎ |____|‎ |‎ (_)‎ |‎ |_|‎ |‎ (_|‎ |____)‎ |‎ |_|‎ |‎ |‎ |‎ |‎ (__‎ 
‎ ‎ \_____|_|\___/‎ \__,_|\__,_|_____/‎ \__,‎ |_|‎ |_|\___|
‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ __/‎ |‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ 
‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ |___/‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ ‎ 
"""

logger = logging.getLogger(__name__)


def print_boot_message():
    settings = get_settings()
    logger.info(MESSAGE)
    logger.info(f"Starting Cloud Sync v{__version__}...")
    logger.info("")
    logger.info("Initialised with the following settings: ")
    logger.info(
        settings.model_dump_json(
            include={"claimed_domains", "target_filter", "telemetry", "perform_sync"}
        )
    )
    logger.info("")
    logger.info(
        "This script will sync user mailboxes and shared mailboxes from Microsoft Exchange Online to the SCIM API of Zivver."
    )
    logger.info("")
