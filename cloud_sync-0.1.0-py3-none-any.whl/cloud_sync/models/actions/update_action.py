from __future__ import annotations
from pydantic import BaseModel, Field, model_validator

from cloud_sync.models.account import Account
from cloud_sync.models.email_address import EmailAddress


class Diff(BaseModel):
    full_name: str | None = Field(default=None)
    is_active: bool | None = Field(default=None)
    aliases: frozenset[EmailAddress] | None = Field(default=None)
    delegations: frozenset[EmailAddress] | None = Field(default=None)

    model_config = {
        "frozen": True,
    }

    @property
    def all_none(self) -> bool:
        return all(
            v is None
            for v in [self.full_name, self.is_active, self.aliases, self.delegations]
        )

    @model_validator(mode="after")
    def check_update_both_delegations_and_aliases(self):
        """
        SCIM PUT erases nested fields
        https://zivver.atlassian.net/browse/ENG-12451
        :return:
        """
        if self.aliases is None and self.delegations is not None:
            raise ValueError(
                "If delegations is set, aliases also need to be set, "
                "otherwise they will get erased by a bug in the Zivver API."
            )

        if self.delegations is None and self.aliases is not None:
            raise ValueError(
                "If aliases is set, delegations also need to be set, "
                "otherwise they will get erased by a bug in the Zivver API."
            )

        return self

    def __repr__(self):
        """
        This override enabled better "Click to see difference" in PyCharm
        during test failures as it allows the git-like text diff to show
        which JSON field are different, while if it was all on one line,
        it wouldn't be easy to read.
        """
        return self.model_dump_json(indent=2)

    def __eq__(self, other):
        if not isinstance(other, Diff):
            return False

        return all(
            getattr(self, field) == getattr(other, field)
            for field in ["full_name", "is_active", "aliases", "delegations"]
        )


class UpdateAction(BaseModel):
    account: Account
    diff: Diff
