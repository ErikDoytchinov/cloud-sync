from __future__ import annotations
from cloud_sync.models.account import Account
from cloud_sync.models.actions.create_action import CreateAction
from cloud_sync.models.actions.update_action import Diff, UpdateAction


def show_azure(actions: list[UpdateAction | CreateAction]) -> str:
    s = "\n"
    for action in actions:
        s += _show_action(action) + "\n"

    return s


def _show_action(action: UpdateAction | CreateAction) -> str:
    if isinstance(action, CreateAction):
        return "CREATE\n" + _show_account(action.account)
    if isinstance(action, UpdateAction):
        return (
            "UPDATE\n"
            + action.account.email_address
            + "\n"
            + _show_diff(action.diff, old_account=action.account)
        )


def _show_diff(diff: Diff, old_account: Account) -> str:
    s = ""
    if diff.full_name is not None:
        s += f"  full_name:\t{old_account.full_name} -> {diff.full_name} \n"

    if diff.is_active is not None:
        s += f"  is_active:\t{old_account.is_active} -> {diff.is_active} \n"

    if diff.aliases is not None:
        s += "  aliases:"

        new = diff.aliases
        if len(new) > 0:
            s += "\n"
            for email in new:
                s += f"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{email}\n"
        else:
            s += "\t(erases all aliases)\n"

    if diff.delegations is not None:
        s += "  delegations:"

        new = diff.delegations
        if len(new) > 0:
            s += "\n"
            for email in new:
                s += f"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{email}\n"
        else:
            s += "\t(erases all delegations)\n"

    return s


def _show_account(account: Account) -> str:
    s = ""
    s += f"{account.email_address}\n"
    s += f"\tkind:\t{account.kind}\n"
    s += f"\tfull_name:\t{account.full_name}\n"
    s += f"\tis_active:\t{account.is_active}\n"
    s += "\taliases:"
    if len(account.aliases) == 0:
        s += "\t\t(no aliases)\n"
    else:
        s += "\n"
        for alias in account.aliases:
            s += f"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{alias}\n"
    s += "\tdelegations:"
    if len(account.delegations) == 0:
        s += "\t\t(no delegations)\n"
    else:
        s += "\n"
        for delegation in account.delegations:
            s += f"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{delegation}\n"
    return s.strip()
