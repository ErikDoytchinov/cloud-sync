#!/usr/bin/env python
import base64
import json
import os
from functools import lru_cache

import httpx


@lru_cache
def get_access_token() -> str:
    endpoint = os.getenv("IDENTITY_ENDPOINT")
    if endpoint is None:
        raise ValueError("IDENTITY_ENDPOINT is not set")

    header = os.getenv("IDENTITY_HEADER")
    if header is None:
        raise ValueError("IDENTITY_HEADER is not set")

    response = httpx.get(
        endpoint,
        params={
            "resource": "https://outlook.office365.com/",
            "api-version": "2019-08-01",
        },
        headers={"X-IDENTITY-HEADER": header},
    )
    return response.json()["access_token"]


def get_tenant_id(access_token: str) -> str:
    _, payload, _ = access_token.split(".")
    # tid == tenant id
    return json.loads(base64.b64decode(payload + "==").decode())["tid"]
