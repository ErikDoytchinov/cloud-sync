import logging

import httpx

import cloud_sync.api.make_httpx_client as mkclient
from cloud_sync.models.scim.scim_user_response import ScimUserResponse
from cloud_sync.settings import get_settings
from cloud_sync.version import __version__

logger = logging.getLogger(__name__)


async def get_scim_users() -> ScimUserResponse:
    logger.info("Getting list of user accounts from Zivver...")
    async with mkclient.make_httpx_client() as client:
        response = await client.get(
            url=httpx.URL(get_settings().zivver_api_url + "/scim/v2/Users"),
            headers={
                "Accept": "application/json",
                "Authorization": f"Bearer {get_settings().zivver_api_key.get_secret_value()}",
                "X-Version": "CloudSync/" + __version__,
            },
        )
    if response.status_code != httpx.codes.OK:
        raise ValueError(f"Failed to get SCIM users: {response.text}")
    return ScimUserResponse(**response.json())
