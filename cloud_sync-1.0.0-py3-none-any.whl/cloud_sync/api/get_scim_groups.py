import logging

import httpx

import cloud_sync.api.make_httpx_client as mkclient
from cloud_sync.models.scim.scim_groups_response import ScimGroupResponse
from cloud_sync.settings import get_settings
from cloud_sync.version import __version__

logger = logging.getLogger(__name__)


async def get_scim_groups() -> ScimGroupResponse:
    logger.info("Getting list of user accounts from Zivver...")
    async with mkclient.make_httpx_client() as client:
        response = await client.get(
            url=httpx.URL(get_settings().zivver_api_url + "/scim/v2/Groups"),
            headers={
                "Accept": "application/json",
                "Authorization": f"Bearer {get_settings().zivver_api_key.get_secret_value()}",
                "X-Version": "CloudSync/" + __version__,
            },
        )
    return ScimGroupResponse(**response.json())
