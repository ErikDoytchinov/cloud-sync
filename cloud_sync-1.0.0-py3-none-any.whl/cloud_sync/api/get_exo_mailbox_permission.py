import asyncio
import base64
import logging
from json import JSONDecodeError

import httpx
from tenacity import (
    AsyncRetrying,
    RetryError,
    stop_after_attempt,
    wait_random_exponential,
)

import cloud_sync.api.make_httpx_client as mkclient
from cloud_sync.get_access_token import get_tenant_id
from cloud_sync.models.account import EmailAddress
from cloud_sync.models.exo.mailbox_permissions import ExoMailboxPermissions
from cloud_sync.settings import get_settings

logger = logging.getLogger(__name__)


async def get_exo_mailbox_permission(
    email_address: EmailAddress,
) -> ExoMailboxPermissions:
    tenant_id = get_tenant_id(get_settings().access_token.get_secret_value())
    email_b64 = base64.b64encode(email_address.encode()).decode()
    url = httpx.URL(
        f"https://outlook.office365.com/adminapi/beta"
        f"/{tenant_id}/Mailbox('{email_b64}')/MailboxPermission"
    )

    try:
        async for attempt in AsyncRetrying(
            sleep=log_sleep,
            wait=wait_random_exponential(multiplier=1, max=60),
            stop=stop_after_attempt(7),
        ):
            with attempt:
                async with mkclient.make_httpx_client() as client:
                    request = client.build_request(
                        "GET",
                        url,
                        params={"isEncoded": "true"},
                        headers={
                            "Accept": "application/json;odata.metadata=minimal",
                            "Authorization": f"Bearer {get_settings().access_token.get_secret_value()}",
                            "ps-version": "7.2.9",
                            "is-cloud-shell": "True",
                            "os-version": "Unix 14.4.1",
                            "exomodule-version": "3.4.0",
                            "Prefer": "odata.maxpagesize=1000;",
                            "OData-Version": "4.0",
                            "OData-MaxVersion": "4.0",
                        },
                    )
                    # logger.info(Curlify(request).to_curl())
                    response = await client.send(request)
    except RetryError as e:
        raise IOError("Failed to get mailbox permission", e)
    else:
        try:
            return ExoMailboxPermissions(**response.json())
        except JSONDecodeError as e:
            raise ValueError(
                f"Failed to parse mailbox permission, content was : {response.text}", e
            )


async def log_sleep(seconds: float):
    logger.info(
        f"Backing off for {seconds:.2f} seconds because Microsoft is rate limiting us 😭"
    )
    await asyncio.sleep(seconds)
