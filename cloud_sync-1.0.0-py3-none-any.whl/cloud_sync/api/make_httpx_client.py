import ssl

import certifi
import httpx


def make_httpx_client() -> httpx.AsyncClient:
    """
    Wraps client creation in a function to allow overwrite with mock patching during testing.
    https://www.b-list.org/weblog/2023/dec/08/mock-python-httpx/
    """
    # https://www.python-httpx.org/advanced/ssl/
    # https://docs.python.org/3.8/library/ssl.html#ssl-security
    ssl_context = ssl.create_default_context(cafile=certifi.where())
    return httpx.AsyncClient(timeout=10.0, verify=ssl_context)
