import logging
import logging.config
import os

from cloud_sync.settings import Settings


def setup_logging(settings: Settings):
    standard_logger = {
        "format": "%(levelname)s %(asctime)s [%(name)s] %(message)s",
        "datefmt": "%Y-%m-%d %H:%M:%S",
    }
    color_logger = {
        "()": "colorlog.ColoredFormatter",
        "format": "%(fg_thin_purple)s%(asctime)s%(reset)s %(white)s%(name)-10s%(reset)s %(log_color)s[%(levelname)-8s]%(reset)s %(cyan)s%(message)s",
    }
    log_config = {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "standard": color_logger if os.name != "nt" else standard_logger,
            "json": {
                "()": "cloud_sync.log.zivver_logger.JSONFormatterLogger",
            },
        },
        "handlers": {
            "console": {
                "level": "NOTSET",
                "formatter": "standard",
                "class": "logging.StreamHandler",
            },
            "zivver": {
                "level": "NOTSET",
                "formatter": "json",
                "class": "cloud_sync.log.zivver_logger.LogRequestsHandler",
            },
        },
        "root": {
            "handlers": ["console", "zivver"] if settings.telemetry else ["console"],
            "level": "NOTSET",
        },
        "loggers": {
            "httpcore": {
                "handlers": ["console"],
                "level": "ERROR",
                "propagate": False,
            },
            "httpx": {
                "handlers": ["console"],
                "level": "WARNING",
                "propagate": False,
            },
            "cloud_sync": {
                "handlers": ["console", "zivver"]
                if settings.telemetry
                else ["console"],
                "level": str(settings.log_level.value),
                "propagate": False,
            },
        },
    }
    logging.config.dictConfig(log_config)
