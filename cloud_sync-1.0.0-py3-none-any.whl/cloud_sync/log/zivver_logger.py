import json
import logging

import httpx

from cloud_sync.version import __version__


class LogRequestsHandler(logging.Handler):
    """
    https://stackoverflow.com/a/63014164
    """

    def emit(self, record: logging.LogRecord) -> None:
        if "httpcore" in record.name:
            return
        json_log_entry: dict = json.loads(self.format(record))
        resp = httpx.request(
            "POST",
            "https://app.zivver.com/api/log",
            json=json_log_entry,
            headers={
                "User-Agent": "CloudSync/" + __version__,
            },
        )
        if resp.status_code // 100 != 2:
            raise ValueError(f"Failed to log to Zivver: {resp.text}")


class JSONFormatterLogger(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        data = {
            "level": "INFO",
            "message": str(record.msg)[:254],
            "whoami": "CloudSync",  # For our backend friends
            "context": {
                "loglevel": record.levelname,
                "func_name": record.funcName,
                "lineno": record.lineno,
                "exc_info": record.exc_info,
                "exc_text": record.exc_text,
                "message": str(record.msg),
            },
            "channel": "cloud_sync",
        }

        return json.dumps(data)
