import os
from enum import Enum

from colorama import Fore, Style


class LogColor(str, Enum):
    YELLOW = Fore.YELLOW if os.name != "nt" else ""
    CYAN = Fore.CYAN if os.name != "nt" else ""
    GREEN = Fore.GREEN if os.name != "nt" else ""
    RED = Fore.RED if os.name != "nt" else ""
    LIGHTBLACK_EX = Fore.LIGHTBLACK_EX if os.name != "nt" else ""
    RESET = Style.RESET_ALL if os.name != "nt" else ""
