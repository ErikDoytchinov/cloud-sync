from __future__ import annotations

from uuid import UUID

from pydantic import BaseModel, Secret

from cloud_sync.models.email_address import EmailAddress

SSOKey = Secret[UUID]


class ExoContext(BaseModel):
    """
    EXO specific data obtained alongside the accounts
    """

    sso_keys: dict[EmailAddress, SSOKey]

    model_config = {
        "frozen": True,
    }
