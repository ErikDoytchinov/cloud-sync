from __future__ import annotations

import json
import logging
from enum import Enum

from pydantic import SecretStr, ValidationError, field_validator
from pydantic.fields import Field, FieldInfo
from pydantic_settings import (
    BaseSettings,
    EnvSettingsSource,
    PydanticBaseSettingsSource,
    SettingsConfigDict,
)

from cloud_sync.get_access_token import get_access_token

logger = logging.getLogger(__name__)

try:
    from automationassets import get_automation_variable as _get_automation_variable

    def get_automation_variable(name: str) -> None | str:
        try:
            return _get_automation_variable(name)
        except BaseException:
            return None
except ImportError:
    logger.warning("automationassets not found, defaulting to mock")

    def get_automation_variable(*args, **kwargs):
        return None


class AzureCustomSource(EnvSettingsSource):
    def get_field_value(
        self, field: FieldInfo, field_name: str
    ) -> tuple[any, str, bool]:
        if field_name == "access_token":
            try:
                access_token = get_access_token()
            except BaseException:
                access_token = None

            return (
                access_token,
                field_name,
                False,
            )
        if field_name == "claimed_domains":
            claimed_domains = get_automation_variable("CLOUD_SYNC__CLAIMED_DOMAINS")
            return (
                json.loads(claimed_domains) if claimed_domains is not None else None,
                field_name,
                False,
            )
        return (
            get_automation_variable(f"CLOUD_SYNC__{field_name.upper()}"),
            field_name,
            False,
        )

    def prepare_field_value(
        self, field_name: str, field: FieldInfo, value: any, value_is_complex: bool
    ) -> any:
        return value

    def decode_complex_value(
        self, field_name: str, field: FieldInfo, value: any
    ) -> any:
        raise NotImplementedError("AzureCustomSource does not support complex values")


class LogLevel(str, Enum):
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env", env_file_encoding="utf-8", env_prefix="CLOUD_SYNC__"
    )

    access_token: SecretStr
    zivver_api_key: SecretStr
    zivver_api_url: str
    claimed_domains: frozenset[str]
    log_level: LogLevel
    perform_sync: bool
    telemetry: bool = Field(default=True)

    @field_validator("zivver_api_url", mode="after")
    @classmethod
    def validate_zivver_api_url(cls, url: str) -> str:
        url = url.strip('"').strip()
        if not url.startswith("http"):
            raise ValueError("CLOUD_SYNC__ZIVVER_API_URL must start with 'http'")
        if not url.startswith("https"):
            raise ValueError("CLOUD_SYNC__ZIVVER_API_URI must start with 'https://'")
        if url.endswith("/"):
            raise ValueError(
                "CLOUD_SYNC__ZIVVER_API_URL must not end with a trailing slash"
            )
        return url

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: BaseSettings,
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        return (
            init_settings,
            env_settings,
            dotenv_settings,
            AzureCustomSource(settings_cls),
            file_secret_settings,
        )


__settings: None | Settings = None


def init_settings():
    try:
        settings = Settings()
    except ValidationError as e:
        raise RuntimeError(
            f"Failed to initialize variables: {e.error_count()} variables are missing: {[error['msg'] for error in e.errors()]}"
        )

    set_settings(settings)


def get_settings() -> Settings:
    if __settings is None:
        raise RuntimeError("Settings not initialized")
    return __settings


def set_settings(settings: Settings) -> None:
    global __settings
    __settings = settings
