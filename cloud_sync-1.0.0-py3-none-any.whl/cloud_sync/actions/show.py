from __future__ import annotations

import os

from colorama import Fore, Style

from cloud_sync.models.account import Account
from cloud_sync.models.actions.create_action import CreateAction
from cloud_sync.models.actions.update_action import Diff, UpdateAction

YELLOW = Fore.YELLOW if os.name != "NT" else ""
CYAN = Fore.CYAN if os.name != "NT" else ""
GREEN = Fore.GREEN if os.name != "NT" else ""
RED = Fore.RED if os.name != "NT" else ""
LIGHTBLACK_EX = Fore.LIGHTBLACK_EX if os.name != "NT" else ""
RESET = Style.RESET_ALL if os.name != "NT" else ""


def show(actions: list[UpdateAction | CreateAction]) -> str:
    s = "\n"
    for action in actions:
        if isinstance(action, CreateAction):
            s += GREEN
        elif isinstance(action, UpdateAction):
            s += CYAN
        else:
            s += YELLOW

        s += _show_action(action) + "\n"

    s += RESET
    return s


def _show_action(action: UpdateAction | CreateAction) -> str:
    if isinstance(action, CreateAction):
        return "CREATE\n" + _show_account(action.account)
    if isinstance(action, UpdateAction):
        return (
            "UPDATE\n"
            + action.account.email_address
            + "\n"
            + CYAN
            + _show_diff(action.diff, old_account=action.account)
            + RESET
        )


def _show_diff(diff: Diff, old_account: Account) -> str:
    s = ""
    if diff.full_name is not None:
        s += f"  full_name:\t{old_account.full_name} -> {diff.full_name} \n"

    if diff.is_active is not None:
        s += f"  is_active:\t{old_account.is_active} -> {diff.is_active} \n"

    if diff.aliases is not None:
        s += "  aliases:"

        new = diff.aliases
        if len(new) > 0:
            s += "\n"
            for email in new:
                s += f"\t{email}\n"
        else:
            s += f"\t{RED}(erases all aliases){CYAN}\n"

    if diff.delegations is not None:
        s += "  delegations:"

        new = diff.delegations
        if len(new) > 0:
            s += "\n"
            for email in new:
                s += f"\t{email}\n"
        else:
            s += f"\t{RED}(erases all delegations){CYAN}\n"

    return s


def _show_account(account: Account) -> str:
    s = ""
    s += f"{account.email_address}\n"
    s += GREEN
    s += f"\tkind:\t{account.kind}\n"
    s += f"\tfull_name:\t{account.full_name}\n"
    s += f"\tis_active:\t{account.is_active}\n"
    s += "\taliases:"
    if len(account.aliases) == 0:
        s += f"\t\t{LIGHTBLACK_EX}(no aliases){GREEN}\n"
    else:
        s += "\n"
        for alias in account.aliases:
            s += f"\t\t{alias}\n"
    s += "\tdelegations:"
    if len(account.delegations) == 0:
        s += f"\t\t{LIGHTBLACK_EX}(no delegations){GREEN}\n"
    else:
        s += "\n"
        for delegation in account.delegations:
            s += f"\t\t{delegation}\n"
    s += RESET
    return s.strip()
